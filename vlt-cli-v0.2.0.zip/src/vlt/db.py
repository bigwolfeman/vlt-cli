from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from vlt.config import settings

engine = create_engine(
    settings.database_url, 
    connect_args={"check_same_thread": False} # Needed for SQLite
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
